const DRUGS_DATA = [
  {
    "name": "Panadol Blue",
    "brand": "Watson",
    "price": 10.99,
    "image": "panadolblue.png"
  },
];
